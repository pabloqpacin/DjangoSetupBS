# DjangoSetup Instructions

Package aimed at setting up a Django project repository.

- [x] Download and extract `DjangoSetup.7z`
- [ ] Read `documentation.md`
- [ ] Run `DjangoSetup.sh`
- [ ] Follow `SecureKey.md`
- [ ] Create the Git repository and keep on developing!